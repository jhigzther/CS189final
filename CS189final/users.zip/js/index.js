var box1 = document.getElementById("u1");
var box2 = document.getElementById("u2");
var box3 = document.getElementById("u3");
var box4 = document.getElementById("u4");
var box5 = document.getElementById("u5");
var box6 = document.getElementById("u6");
var box7 = document.getElementById("u7");
var box8 = document.getElementById("u8");
var box9 = document.getElementById("u9");
var box10 = document.getElementById("u10");

function ajax(url) {
  return new Promise((resolve, reject) => {
    let request = new XMLHttpRequest();
    request.open("GET", url);
    request.onload = function() {
      try {
        if(this.status === 200 ){
          resolve(JSON.parse(this.responseText));
        } 
      else {
        reject(this.status + " " + this.statusText);
      }
      } 
      catch(error) {
      reject(error.message);
      }
  };  
  request.onerror = function() {
    reject(this.status + " " + this.statusText);
  };
    request.send();
  });
}

var promiselist = [];
var user = ajax("https://jsonplaceholder.typicode.com/users");
promiselist.push(user);
for(let i = 0; i < 10; i++) {
  id = i + 1;
	var q = ajax("https://jsonplaceholder.typicode.com/posts?userId=" + id);
	promiselist.push(q);
}

Promise.all(promiselist).then(
 function(p){
    var output1 = "";
    var output2 = "";
    var output3 = "";
    var output4 = "";
    var output5 = "";
    var output6 = "";
    var output7 = "";
    var output8 = "";
    var output9 = "";
    var output10 = "";
  for(let i = 0; i < 1; i++)
  {
    output1 += "<div class='item'>"
    posts = p[i+1];  
    output1 += "<h2><a href='contact1.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 1; i < 2; i++)
  {
    output2 += "<div class='item'>"
    posts = p[i+1];  
    output2 += "<h2><a href='contact2.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 2; i < 3; i++)
  {
    output3 += "<div class='item'>"
    posts = p[i+1];  
    output3 += "<h2><a href='contact3.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 3; i < 4; i++)
  {
    output4 += "<div class='item'>"
    posts = p[i+1];  
    output4 += "<h2><a href='contact4.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 4; i < 5; i++)
  {
    output5 += "<div class='item'>"
    posts = p[i+1];  
    output5 += "<h2><a href='contact5.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 5; i < 6; i++)
  {
    output6 += "<div class='item'>"
    posts = p[i+1];  
    output6 += "<h2><a href='contact6.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 6; i < 7; i++)
  {
    output7 += "<div class='item'>"
    posts = p[i+1];  
    output7 += "<h2><a href='contact7.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 7; i < 8; i++)
  {
    output8 += "<div class='item'>"
    posts = p[i+1];  
    output8 += "<h2><a href='contact8.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 8; i < 9; i++)
  {
    output9 += "<div class='item'>"
    posts = p[i+1];  
    output9 += "<h2><a href='contact9.html'>" + p[0][i].name + "</a></h2></div>"  
  }
   for(let i = 9; i < 10; i++)
  {
    output10 += "<div class='item'>"
    posts = p[i+1];  
    output10 += "<h2><a href='contact10.html'>" + p[0][i].name + "</a></h2></div>"  
  }
  box1.insertAdjacentHTML('beforeend', output1);
   box2.insertAdjacentHTML('beforeend', output2);
   box3.insertAdjacentHTML('beforeend', output3);
   box4.insertAdjacentHTML('beforeend', output4);
   box5.insertAdjacentHTML('beforeend', output5);
   box6.insertAdjacentHTML('beforeend', output6);
   box7.insertAdjacentHTML('beforeend', output7);
   box8.insertAdjacentHTML('beforeend', output8);
   box9.insertAdjacentHTML('beforeend', output9);
   box10.insertAdjacentHTML('beforeend', output10);
 }
);