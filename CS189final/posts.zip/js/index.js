var box = document.getElementById("user");
var box2 = document.getElementById("user2");
var box3 = document.getElementById("userposts");

function ajax(url) {
  return new Promise((resolve, reject) => {
    let request = new XMLHttpRequest();
    request.open("GET", url);
    request.onload = function() {
      try {
        if(this.status === 200 ){
          resolve(JSON.parse(this.responseText));
        } 
      else {
        reject(this.status + " " + this.statusText);
      }
      } 
      catch(error) {
      reject(error.message);
      }
  };  
  request.onerror = function() {
    reject(this.status + " " + this.statusText);
  };
    request.send();
  });
}

var promiselist = [];
var user = ajax("https://jsonplaceholder.typicode.com/users");
promiselist.push(user);
for(let i = 0; i < 10; i++) {
  id = i + 1;
	var q = ajax("https://jsonplaceholder.typicode.com/posts?userId=" + id);
	promiselist.push(q);
}

Promise.all(promiselist).then(
 function(p){
    var output1 = "";
    var output2 = "";
    var output3 = "";
  for(let i = 0; i < 1; i++)
  {
    output1 += p[0][i].name
    output2 += p[0][i].name + "'s Posts"
    output3 += "<h1 class='username'>"  + p[0][i].name + "'s Posts</h1>"
    output3 += "<div class='postlist'>"
    posts = p[i+1];
    for(post=0; post < 10; post++){
      output3 += "<div class='postmalone'><h3>" + posts[post].title + "</h3>"
      output3 += "<p>" + posts[post].body + "</p></div>"
    }
    
    output3 += "</div>"
  }
   box.insertAdjacentHTML('beforeend', output1);
   box2.insertAdjacentHTML('beforeend', output2);
   box3.insertAdjacentHTML('beforeend', output3);
 }
);